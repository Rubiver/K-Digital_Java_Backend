create definer = java@`%` view emp_dept_view as
select `e`.`EMP_ID` AS `emp_id`, `e`.`EMP_NAME` AS `EMP_NAME`, `d`.`DEPT_TITLE` AS `DEPT_TITLE`
from (`java`.`employee` `e` join `java`.`department` `d` on ((`e`.`DEPT_CODE` = `d`.`DEPT_ID`)));

