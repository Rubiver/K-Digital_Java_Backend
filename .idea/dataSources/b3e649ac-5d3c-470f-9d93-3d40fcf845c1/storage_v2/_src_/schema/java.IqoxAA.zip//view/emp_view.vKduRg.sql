create definer = java@`%` view emp_view as
select `java`.`employee`.`EMP_ID`   AS `emp_id`,
       `java`.`employee`.`EMP_NAME` AS `emp_name`,
       `java`.`employee`.`PHONE`    AS `PHONE`,
       `java`.`employee`.`EMAIL`    AS `EMAIL`
from `java`.`employee`;

